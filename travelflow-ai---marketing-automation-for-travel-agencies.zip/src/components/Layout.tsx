import React from 'react';
import { Sidebar } from './Sidebar';

interface LayoutProps {
  children: React.ReactNode;
}

export const Layout = ({ children }: LayoutProps) => {
  return (
    <div className="min-h-screen bg-slate-50">
      <Sidebar />
      <main className="p-4 sm:ml-64">
        <div className="mx-auto max-w-7xl p-4">
          {children}
        </div>
      </main>
    </div>
  );
};
