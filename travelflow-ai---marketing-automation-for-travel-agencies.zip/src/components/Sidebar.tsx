import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  LayoutDashboard, 
  PenTool, 
  Users, 
  Search, 
  MessageSquare, 
  BarChart3, 
  Settings, 
  LogOut,
  Compass
} from 'lucide-react';
import { logout } from '../firebase';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

const navItems = [
  { icon: LayoutDashboard, label: 'Dashboard', path: '/' },
  { icon: PenTool, label: 'AI Content', path: '/content' },
  { icon: Users, label: 'Leads CRM', path: '/leads' },
  { icon: Search, label: 'SEO Tools', path: '/seo' },
  { icon: MessageSquare, label: 'AI Chatbot', path: '/chatbot' },
  { icon: BarChart3, label: 'Analytics', path: '/analytics' },
];

export const Sidebar = () => {
  return (
    <aside className="fixed left-0 top-0 z-40 h-screen w-64 border-r border-slate-200 bg-white px-4 py-6 transition-transform sm:translate-x-0">
      <div className="mb-8 flex items-center gap-3 px-2">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-600 text-white shadow-lg shadow-emerald-200">
          <Compass className="h-6 w-6" />
        </div>
        <span className="text-xl font-bold tracking-tight text-slate-900">TravelFlow AI</span>
      </div>

      <nav className="flex h-[calc(100%-8rem)] flex-col justify-between">
        <div className="space-y-1">
          {navItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                cn(
                  'group flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-all duration-200',
                  isActive
                    ? 'bg-emerald-50 text-emerald-700'
                    : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                )
              }
            >
              <item.icon className="h-5 w-5 shrink-0" />
              <span>{item.label}</span>
            </NavLink>
          ))}
        </div>

        <div className="space-y-1 border-t border-slate-100 pt-4">
          <button
            onClick={() => logout()}
            className="group flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-slate-600 transition-all duration-200 hover:bg-rose-50 hover:text-rose-600"
          >
            <LogOut className="h-5 w-5 shrink-0" />
            <span>Sign Out</span>
          </button>
        </div>
      </nav>
    </aside>
  );
};
