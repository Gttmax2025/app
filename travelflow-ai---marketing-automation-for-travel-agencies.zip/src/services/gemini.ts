import { GoogleGenAI, Type } from "@google/genai";

const API_KEY = process.env.GEMINI_API_KEY || '';

export const generateContent = async (prompt: string, systemInstruction: string) => {
  if (!API_KEY) {
    throw new Error("Gemini API key is missing. Please add it to your environment variables.");
  }

  const ai = new GoogleGenAI({ apiKey: API_KEY });
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      systemInstruction,
      temperature: 0.7,
      topP: 0.95,
      topK: 64,
    },
  });

  return response.text;
};

export const getTravelRecommendations = async (userPreferences: any) => {
  if (!API_KEY) {
    throw new Error("Gemini API key is missing.");
  }

  const ai = new GoogleGenAI({ apiKey: API_KEY });
  const systemInstruction = "You are a personalized travel recommendation engine. Analyze user preferences and historical data to suggest relevant destinations, activities, and travel packages. Return the results in a structured JSON format.";
  
  const prompt = `Based on the following user profile, provide 3 personalized travel recommendations:
  Interests: ${userPreferences.interests.join(', ')}
  Budget: ${userPreferences.budget}
  Travel Style: ${userPreferences.travelStyle}
  Past Destinations: ${userPreferences.pastDestinations.join(', ')}
  
  Ensure the recommendations are dynamic and consider current travel trends.`;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      systemInstruction,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            destination: { type: Type.STRING },
            reason: { type: Type.STRING, description: "Why this destination matches the user's profile." },
            activities: { type: Type.ARRAY, items: { type: Type.STRING } },
            estimatedCost: { type: Type.STRING },
            matchScore: { type: Type.NUMBER, description: "A score from 0 to 100 indicating how well this matches the user." }
          },
          required: ["destination", "reason", "activities", "estimatedCost", "matchScore"]
        }
      }
    }
  });

  return JSON.parse(response.text);
};

export const generateBlog = async (destination: string, keywords: string[]) => {
  const systemInstruction = "You are an expert travel blogger and SEO specialist. Create high-quality, engaging, and SEO-optimized blog posts for travel agencies.";
  const prompt = `Write a comprehensive, SEO-optimized blog post about ${destination}. 
  Include these keywords: ${keywords.join(', ')}. 
  The post should include:
  1. A catchy title.
  2. An engaging introduction.
  3. 3-5 subheadings with detailed content.
  4. Practical travel tips.
  5. A strong call to action to book a trip.
  Format the output in Markdown.`;

  return generateContent(prompt, systemInstruction);
};

export const generateSocialMedia = async (destination: string, platform: string) => {
  const systemInstruction = "You are a social media manager for a luxury travel agency. You specialize in viral travel content.";
  const prompt = `Create a ${platform} content pack for ${destination}. 
  Include:
  1. 3 different caption options (engaging, informative, and short).
  2. 15 relevant and trending hashtags.
  3. A script for a 30-second Reel/TikTok.
  4. Text for a 5-slide carousel post.
  Format the output in Markdown.`;

  return generateContent(prompt, systemInstruction);
};

export const generateEmail = async (destination: string, offer: string) => {
  const systemInstruction = "You are a direct response email marketer for the travel industry.";
  const prompt = `Create a high-converting email newsletter about ${destination}. 
  The focus is on this special offer: ${offer}.
  Include:
  1. 3 compelling subject line options.
  2. A personalized greeting.
  3. An exciting body text that highlights the destination and the offer.
  4. A clear, urgent call to action.
  Format the output in Markdown.`;

  return generateContent(prompt, systemInstruction);
};

export const generateItinerary = async (destination: string, days: number) => {
  const systemInstruction = "You are a professional travel planner with deep local knowledge of global destinations.";
  const prompt = `Create a detailed ${days}-day travel itinerary for ${destination}. 
  Include:
  1. Daily breakdown of activities (morning, afternoon, evening).
  2. Recommended local restaurants and dishes to try.
  3. Transportation tips.
  4. Estimated budget categories (budget, mid-range, luxury).
  Format the output in Markdown.`;

  return generateContent(prompt, systemInstruction);
};

export const keywordResearch = async (niche: string) => {
  const systemInstruction = "You are an SEO analyst specializing in the travel and tourism niche.";
  const prompt = `Perform keyword research for the travel niche: ${niche}. 
  Provide:
  1. 10 high-volume primary keywords.
  2. 15 long-tail keywords with low competition.
  3. 5 trending topics for blog posts.
  4. 5 "People Also Ask" questions related to this niche.
  Format the output in Markdown.`;

  return generateContent(prompt, systemInstruction);
};
