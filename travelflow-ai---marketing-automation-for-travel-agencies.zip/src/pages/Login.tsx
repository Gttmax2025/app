import React from 'react';
import { loginWithGoogle } from '../firebase';
import { Button } from '../components/Button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../components/Card';
import { Compass, Globe, Zap, Shield } from 'lucide-react';

export const Login = () => {
  return (
    <div className="flex min-h-screen items-center justify-center bg-slate-50 p-4">
      <div className="grid w-full max-w-5xl gap-12 lg:grid-cols-2">
        <div className="flex flex-col justify-center space-y-8">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-emerald-600 text-white shadow-xl shadow-emerald-200">
              <Compass className="h-8 w-8" />
            </div>
            <h1 className="text-3xl font-bold tracking-tight text-slate-900">TravelFlow AI</h1>
          </div>
          
          <div className="space-y-4">
            <h2 className="text-5xl font-extrabold leading-tight tracking-tight text-slate-900">
              Automate Your <span className="text-emerald-600">Travel Marketing</span>
            </h2>
            <p className="text-xl text-slate-600">
              The all-in-one AI suite for travel agencies to generate leads, create content, and scale organically.
            </p>
          </div>

          <div className="grid gap-6 sm:grid-cols-2">
            <div className="flex items-start gap-3">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-emerald-100 text-emerald-600">
                <Zap className="h-5 w-5" />
              </div>
              <div>
                <h3 className="font-semibold text-slate-900">AI Content</h3>
                <p className="text-sm text-slate-500">Generate blogs, social posts & itineraries in seconds.</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-blue-100 text-blue-600">
                <Globe className="h-5 w-5" />
              </div>
              <div>
                <h3 className="font-semibold text-slate-900">SEO Tools</h3>
                <p className="text-sm text-slate-500">Rank higher with automated keyword research.</p>
              </div>
            </div>
          </div>
        </div>

        <div className="flex items-center justify-center">
          <Card className="w-full max-w-md border-slate-200 p-8 shadow-2xl shadow-slate-200">
            <CardHeader className="text-center">
              <CardTitle className="text-2xl">Welcome Back</CardTitle>
              <CardDescription>Sign in to manage your travel agency's marketing</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6 pt-6">
              <Button 
                variant="outline" 
                className="w-full gap-3 py-6 text-lg"
                onClick={() => loginWithGoogle()}
              >
                <img src="https://www.google.com/favicon.ico" alt="Google" className="h-5 w-5" />
                Continue with Google
              </Button>
              
              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t border-slate-200" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-white px-2 text-slate-500">Secure Access</span>
                </div>
              </div>

              <div className="flex items-center justify-center gap-2 text-sm text-slate-500">
                <Shield className="h-4 w-4" />
                <span>Enterprise-grade security by Firebase</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};
