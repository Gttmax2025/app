import React, { useState } from 'react';
import { db, auth, OperationType, handleFirestoreError } from '../firebase';
import { collection, addDoc } from 'firebase/firestore';
import { generateBlog, generateSocialMedia, generateEmail, generateItinerary } from '../services/gemini';
import { Button } from '../components/Button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../components/Card';
import { 
  PenTool, 
  Globe, 
  Mail, 
  Instagram, 
  Map, 
  Sparkles, 
  Copy, 
  Check, 
  Save,
  Loader2
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';

type ContentType = 'blog' | 'social' | 'email' | 'itinerary';

export const ContentGenerator = () => {
  const [type, setType] = useState<ContentType>('blog');
  const [destination, setDestination] = useState('');
  const [keywords, setKeywords] = useState('');
  const [offer, setOffer] = useState('');
  const [days, setDays] = useState(5);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState('');
  const [copied, setCopied] = useState(false);
  const [saved, setSaved] = useState(false);

  const handleGenerate = async () => {
    if (!destination) return;
    setLoading(true);
    setResult('');
    setSaved(false);
    
    try {
      let content = '';
      if (type === 'blog') {
        content = await generateBlog(destination, keywords.split(',').map(k => k.trim()));
      } else if (type === 'social') {
        content = await generateSocialMedia(destination, 'Instagram');
      } else if (type === 'email') {
        content = await generateEmail(destination, offer);
      } else if (type === 'itinerary') {
        content = await generateItinerary(destination, days);
      }
      setResult(content);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!result || !auth.currentUser) return;
    
    try {
      await addDoc(collection(db, 'content'), {
        type,
        title: `${type.toUpperCase()}: ${destination}`,
        body: result,
        destination,
        createdAt: new Date().toISOString(),
        uid: auth.currentUser.uid,
      });
      setSaved(true);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'content');
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(result);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const types = [
    { id: 'blog', label: 'Blog Post', icon: Globe, color: 'text-blue-600', bg: 'bg-blue-50' },
    { id: 'social', label: 'Social Media', icon: Instagram, color: 'text-pink-600', bg: 'bg-pink-50' },
    { id: 'email', label: 'Email Campaign', icon: Mail, color: 'text-amber-600', bg: 'bg-amber-50' },
    { id: 'itinerary', label: 'Travel Itinerary', icon: Map, color: 'text-emerald-600', bg: 'bg-emerald-50' },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-slate-900">AI Content Generator</h1>
        <p className="text-slate-500">Create high-quality travel marketing materials in seconds.</p>
      </div>

      <div className="grid gap-8 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-1">
          <Card className="border-slate-100">
            <CardHeader>
              <CardTitle>Content Settings</CardTitle>
              <CardDescription>Configure your AI generation parameters.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6 pt-4">
              <div className="space-y-3">
                <label className="text-sm font-medium text-slate-700">Content Type</label>
                <div className="grid grid-cols-2 gap-2">
                  {types.map((t) => (
                    <button
                      key={t.id}
                      onClick={() => setType(t.id as ContentType)}
                      className={cn(
                        'flex flex-col items-center justify-center gap-2 rounded-xl border p-3 transition-all',
                        type === t.id 
                          ? 'border-emerald-600 bg-emerald-50 text-emerald-700 shadow-sm' 
                          : 'border-slate-100 bg-white text-slate-500 hover:border-slate-200 hover:bg-slate-50'
                      )}
                    >
                      <t.icon className={cn('h-5 w-5', type === t.id ? t.color : 'text-slate-400')} />
                      <span className="text-xs font-medium">{t.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700">Destination</label>
                <input
                  type="text"
                  placeholder="e.g. Bali, Indonesia"
                  className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-emerald-500 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  value={destination}
                  onChange={(e) => setDestination(e.target.value)}
                />
              </div>

              {type === 'blog' && (
                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-700">Keywords (comma separated)</label>
                  <textarea
                    placeholder="e.g. luxury travel, beach resorts, adventure"
                    className="h-24 w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-emerald-500 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                    value={keywords}
                    onChange={(e) => setKeywords(e.target.value)}
                  />
                </div>
              )}

              {type === 'email' && (
                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-700">Special Offer</label>
                  <input
                    type="text"
                    placeholder="e.g. 20% off for early bookings"
                    className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-emerald-500 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                    value={offer}
                    onChange={(e) => setOffer(e.target.value)}
                  />
                </div>
              )}

              {type === 'itinerary' && (
                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-700">Duration (Days)</label>
                  <input
                    type="number"
                    min={1}
                    max={30}
                    className="w-full rounded-lg border border-slate-200 px-3 py-2 text-sm focus:border-emerald-500 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                    value={days}
                    onChange={(e) => setDays(parseInt(e.target.value))}
                  />
                </div>
              )}

              <Button 
                className="w-full gap-2" 
                onClick={handleGenerate}
                isLoading={loading}
                disabled={!destination}
              >
                <Sparkles className="h-4 w-4" />
                Generate Content
              </Button>
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-2">
          <Card className="min-h-[600px] border-slate-100">
            <CardHeader className="flex flex-row items-center justify-between border-b border-slate-100 pb-4">
              <div>
                <CardTitle>AI Result</CardTitle>
                <CardDescription>Your generated marketing content will appear here.</CardDescription>
              </div>
              {result && (
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={handleCopy}>
                    {copied ? <Check className="h-4 w-4 text-emerald-600" /> : <Copy className="h-4 w-4" />}
                  </Button>
                  <Button variant="outline" size="sm" onClick={handleSave} disabled={saved}>
                    {saved ? <Check className="h-4 w-4 text-emerald-600" /> : <Save className="h-4 w-4" />}
                  </Button>
                </div>
              )}
            </CardHeader>
            <CardContent className="prose prose-slate max-w-none pt-6">
              {loading ? (
                <div className="flex h-96 flex-col items-center justify-center space-y-4 text-center">
                  <Loader2 className="h-12 w-12 animate-spin text-emerald-600" />
                  <p className="text-slate-500">AI is crafting your travel content...</p>
                </div>
              ) : result ? (
                <div className="markdown-body">
                  <ReactMarkdown>{result}</ReactMarkdown>
                </div>
              ) : (
                <div className="flex h-96 flex-col items-center justify-center text-center">
                  <PenTool className="mb-4 h-16 w-16 text-slate-100" />
                  <p className="text-slate-400">Select a type and destination to start generating.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

function cn(...inputs: any[]) {
  return inputs.filter(Boolean).join(' ');
}
