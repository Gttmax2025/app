import React, { useEffect, useState } from 'react';
import { db, auth, OperationType, handleFirestoreError } from '../firebase';
import { collection, query, where, onSnapshot, orderBy, limit } from 'firebase/firestore';
import { AnalyticsData } from '../types';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../components/Card';
import { 
  BarChart3, 
  TrendingUp, 
  Users, 
  Target, 
  ArrowUpRight, 
  ArrowDownRight,
  Globe,
  MousePointer2,
  Calendar
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  PieChart, 
  Pie, 
  Cell,
  Legend
} from 'recharts';

export const Analytics = () => {
  const [analytics, setAnalytics] = useState<AnalyticsData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!auth.currentUser) return;

    const analyticsQuery = query(
      collection(db, 'analytics'),
      where('uid', '==', auth.currentUser.uid),
      orderBy('date', 'desc'),
      limit(30)
    );

    const unsub = onSnapshot(analyticsQuery, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as AnalyticsData));
      setAnalytics(data.reverse());
      setLoading(false);
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'analytics'));

    return () => unsub();
  }, []);

  const COLORS = ['#10b981', '#3b82f6', '#8b5cf6', '#f59e0b'];

  const leadSourceData = [
    { name: 'Blog Posts', value: 45 },
    { name: 'Social Media', value: 30 },
    { name: 'Email Marketing', value: 15 },
    { name: 'AI Chatbot', value: 10 },
  ];

  if (loading) {
    return (
      <div className="flex h-[80vh] items-center justify-center">
        <div className="h-12 w-12 animate-spin rounded-full border-4 border-emerald-600 border-t-transparent" />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Analytics & Insights</h1>
          <p className="text-slate-500">Track your travel agency's growth and marketing performance.</p>
        </div>
        <div className="flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-600">
          <Calendar className="h-4 w-4" />
          Last 30 Days
        </div>
      </div>

      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {[
          { label: 'Total Traffic', value: '12,450', icon: Globe, color: 'text-blue-600', bg: 'bg-blue-50', trend: '+15%' },
          { label: 'Lead Conversion', value: '4.2%', icon: Target, color: 'text-emerald-600', bg: 'bg-emerald-50', trend: '+2.1%' },
          { label: 'Avg. Session', value: '3m 45s', icon: MousePointer2, color: 'text-purple-600', bg: 'bg-purple-50', trend: '-5%' },
          { label: 'Marketing ROI', value: '3.8x', icon: TrendingUp, color: 'text-amber-600', bg: 'bg-amber-50', trend: '+12%' },
        ].map((stat) => (
          <Card key={stat.label} className="border-slate-100">
            <div className="flex items-center justify-between">
              <div className={cn('flex h-10 w-10 items-center justify-center rounded-lg', stat.bg, stat.color)}>
                <stat.icon className="h-5 w-5" />
              </div>
              <div className={cn('flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider', stat.trend.startsWith('+') ? 'text-emerald-600' : 'text-rose-600')}>
                {stat.trend.startsWith('+') ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
                {stat.trend}
              </div>
            </div>
            <div className="mt-4">
              <p className="text-xs font-medium text-slate-500">{stat.label}</p>
              <h3 className="text-xl font-bold text-slate-900">{stat.value}</h3>
            </div>
          </Card>
        ))}
      </div>

      <div className="grid gap-8 lg:grid-cols-3">
        <Card className="lg:col-span-2 border-slate-100">
          <CardHeader>
            <CardTitle>Traffic vs. Leads</CardTitle>
            <CardDescription>Daily correlation between website visitors and captured leads.</CardDescription>
          </CardHeader>
          <CardContent className="h-[400px] w-full pt-4">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={analytics}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="date" stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#fff', borderRadius: '12px', border: '1px solid #e2e8f0', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                />
                <Legend iconType="circle" />
                <Bar dataKey="traffic" fill="#3b82f6" radius={[4, 4, 0, 0]} name="Traffic" />
                <Bar dataKey="leadsGenerated" fill="#10b981" radius={[4, 4, 0, 0]} name="Leads" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="border-slate-100">
          <CardHeader>
            <CardTitle>Lead Sources</CardTitle>
            <CardDescription>Where your potential customers are coming from.</CardDescription>
          </CardHeader>
          <CardContent className="h-[400px] w-full pt-4">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={leadSourceData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {leadSourceData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ backgroundColor: '#fff', borderRadius: '12px', border: '1px solid #e2e8f0', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                />
                <Legend verticalAlign="bottom" align="center" iconType="circle" />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

function cn(...inputs: any[]) {
  return inputs.filter(Boolean).join(' ');
}
