import React, { useEffect, useState } from 'react';
import { db, auth, OperationType, handleFirestoreError } from '../firebase';
import { collection, query, where, onSnapshot, orderBy, limit } from 'firebase/firestore';
import { Lead, MarketingContent, AnalyticsData } from '../types';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../components/Card';
import { Button } from '../components/Button';
import { 
  Users, 
  PenTool, 
  TrendingUp, 
  ArrowUpRight, 
  ArrowDownRight, 
  Plus, 
  Calendar,
  ChevronRight
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';

export const Dashboard = () => {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [content, setContent] = useState<MarketingContent[]>([]);
  const [analytics, setAnalytics] = useState<AnalyticsData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!auth.currentUser) return;

    const leadsQuery = query(
      collection(db, 'leads'),
      where('uid', '==', auth.currentUser.uid),
      orderBy('createdAt', 'desc'),
      limit(5)
    );

    const contentQuery = query(
      collection(db, 'content'),
      where('uid', '==', auth.currentUser.uid),
      orderBy('createdAt', 'desc'),
      limit(5)
    );

    const analyticsQuery = query(
      collection(db, 'analytics'),
      where('uid', '==', auth.currentUser.uid),
      orderBy('date', 'desc'),
      limit(7)
    );

    const unsubLeads = onSnapshot(leadsQuery, (snapshot) => {
      setLeads(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Lead)));
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'leads'));

    const unsubContent = onSnapshot(contentQuery, (snapshot) => {
      setContent(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as MarketingContent)));
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'content'));

    const unsubAnalytics = onSnapshot(analyticsQuery, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as AnalyticsData));
      setAnalytics(data.reverse());
      setLoading(false);
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'analytics'));

    return () => {
      unsubLeads();
      unsubContent();
      unsubAnalytics();
    };
  }, []);

  const stats = [
    { label: 'Total Leads', value: leads.length, icon: Users, color: 'text-blue-600', bg: 'bg-blue-50' },
    { label: 'AI Content', value: content.length, icon: PenTool, color: 'text-emerald-600', bg: 'bg-emerald-50' },
    { label: 'Avg. Conversion', value: '4.2%', icon: TrendingUp, color: 'text-purple-600', bg: 'bg-purple-50' },
  ];

  if (loading) {
    return (
      <div className="flex h-[80vh] items-center justify-center">
        <div className="h-12 w-12 animate-spin rounded-full border-4 border-emerald-600 border-t-transparent" />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Marketing Dashboard</h1>
          <p className="text-slate-500">Welcome back! Here's how your travel agency is performing.</p>
        </div>
        <div className="flex gap-3">
          <Link to="/content">
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              New AI Content
            </Button>
          </Link>
        </div>
      </div>

      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {stats.map((stat) => (
          <Card key={stat.label} className="border-slate-100">
            <div className="flex items-center justify-between">
              <div className={cn('flex h-12 w-12 items-center justify-center rounded-xl', stat.bg, stat.color)}>
                <stat.icon className="h-6 w-6" />
              </div>
              <div className="flex items-center gap-1 text-xs font-medium text-emerald-600">
                <ArrowUpRight className="h-3 w-3" />
                12%
              </div>
            </div>
            <div className="mt-4">
              <p className="text-sm font-medium text-slate-500">{stat.label}</p>
              <h3 className="text-2xl font-bold text-slate-900">{stat.value}</h3>
            </div>
          </Card>
        ))}
      </div>

      <div className="grid gap-8 lg:grid-cols-2">
        <Card className="border-slate-100">
          <CardHeader>
            <CardTitle>Lead Growth</CardTitle>
            <CardDescription>Daily lead generation performance over the last 7 days.</CardDescription>
          </CardHeader>
          <CardContent className="h-[300px] w-full pt-4">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={analytics}>
                <defs>
                  <linearGradient id="colorLeads" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="date" stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#fff', borderRadius: '12px', border: '1px solid #e2e8f0', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                />
                <Area type="monotone" dataKey="leadsGenerated" stroke="#10b981" strokeWidth={3} fillOpacity={1} fill="url(#colorLeads)" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="border-slate-100">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Recent Leads</CardTitle>
              <CardDescription>Latest potential customers captured.</CardDescription>
            </div>
            <Link to="/leads">
              <Button variant="ghost" size="sm" className="text-emerald-600">View All</Button>
            </Link>
          </CardHeader>
          <CardContent className="space-y-4 pt-4">
            {leads.length > 0 ? leads.map((lead) => (
              <div key={lead.id} className="flex items-center justify-between rounded-xl border border-slate-50 bg-slate-50/50 p-3 transition-all hover:border-emerald-100 hover:bg-emerald-50/30">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-white text-slate-600 shadow-sm">
                    {lead.name.charAt(0)}
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold text-slate-900">{lead.name}</h4>
                    <p className="text-xs text-slate-500">{lead.email}</p>
                  </div>
                </div>
                <div className="text-right">
                  <span className="inline-flex rounded-full bg-emerald-100 px-2.5 py-0.5 text-[10px] font-medium text-emerald-700">
                    {lead.source}
                  </span>
                  <p className="mt-1 text-[10px] text-slate-400">
                    {new Date(lead.createdAt).toLocaleDateString()}
                  </p>
                </div>
              </div>
            )) : (
              <div className="flex h-48 flex-col items-center justify-center text-center">
                <Users className="mb-2 h-12 w-12 text-slate-200" />
                <p className="text-sm text-slate-500">No leads captured yet.</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

function cn(...inputs: any[]) {
  return inputs.filter(Boolean).join(' ');
}
