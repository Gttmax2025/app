import React, { useState } from 'react';
import { keywordResearch } from '../services/gemini';
import { Button } from '../components/Button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../components/Card';
import { 
  Search, 
  TrendingUp, 
  Globe, 
  Sparkles, 
  Copy, 
  Check, 
  Loader2,
  BarChart3,
  MousePointer2
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';

export const SEOTools = () => {
  const [niche, setNiche] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState('');
  const [copied, setCopied] = useState(false);

  const handleResearch = async () => {
    if (!niche) return;
    setLoading(true);
    setResult('');
    
    try {
      const content = await keywordResearch(niche);
      setResult(content);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(result);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-slate-900">SEO & Traffic Automation</h1>
        <p className="text-slate-500">Perform keyword research and optimize your travel content for organic growth.</p>
      </div>

      <div className="grid gap-8 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-1">
          <Card className="border-slate-100">
            <CardHeader>
              <CardTitle>Keyword Research</CardTitle>
              <CardDescription>Enter your travel niche or destination to find trending keywords.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6 pt-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700">Travel Niche / Destination</label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    placeholder="e.g. Adventure Travel in Iceland"
                    className="w-full rounded-xl border border-slate-200 bg-slate-50/50 py-2.5 pl-10 pr-4 text-sm focus:border-emerald-500 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                    value={niche}
                    onChange={(e) => setNiche(e.target.value)}
                  />
                </div>
              </div>

              <Button 
                className="w-full gap-2" 
                onClick={handleResearch}
                isLoading={loading}
                disabled={!niche}
              >
                <Sparkles className="h-4 w-4" />
                Analyze Keywords
              </Button>

              <div className="space-y-4 pt-4">
                <div className="flex items-center gap-3 rounded-xl border border-slate-100 bg-slate-50/50 p-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-100 text-blue-600">
                    <TrendingUp className="h-5 w-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-semibold text-slate-900">Trend Analysis</h4>
                    <p className="text-[10px] text-slate-500">Find what's trending in travel right now.</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 rounded-xl border border-slate-100 bg-slate-50/50 p-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-100 text-purple-600">
                    <MousePointer2 className="h-5 w-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-semibold text-slate-900">Long-tail Keywords</h4>
                    <p className="text-[10px] text-slate-500">Target low-competition, high-intent phrases.</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-2">
          <Card className="min-h-[600px] border-slate-100">
            <CardHeader className="flex flex-row items-center justify-between border-b border-slate-100 pb-4">
              <div>
                <CardTitle>Research Report</CardTitle>
                <CardDescription>AI-generated SEO insights and keyword opportunities.</CardDescription>
              </div>
              {result && (
                <Button variant="outline" size="sm" onClick={handleCopy}>
                  {copied ? <Check className="h-4 w-4 text-emerald-600" /> : <Copy className="h-4 w-4" />}
                </Button>
              )}
            </CardHeader>
            <CardContent className="prose prose-slate max-w-none pt-6">
              {loading ? (
                <div className="flex h-96 flex-col items-center justify-center space-y-4 text-center">
                  <Loader2 className="h-12 w-12 animate-spin text-emerald-600" />
                  <p className="text-slate-500">AI is analyzing search trends...</p>
                </div>
              ) : result ? (
                <div className="markdown-body">
                  <ReactMarkdown>{result}</ReactMarkdown>
                </div>
              ) : (
                <div className="flex h-96 flex-col items-center justify-center text-center">
                  <BarChart3 className="mb-4 h-16 w-16 text-slate-100" />
                  <p className="text-slate-400">Enter a niche to start your keyword research.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};
