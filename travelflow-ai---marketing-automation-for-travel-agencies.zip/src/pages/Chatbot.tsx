import React, { useState, useRef, useEffect } from 'react';
import { db, auth, OperationType, handleFirestoreError } from '../firebase';
import { collection, addDoc, query, where, getDocs, limit, orderBy } from 'firebase/firestore';
import { GoogleGenAI } from "@google/genai";
import { getTravelRecommendations } from '../services/gemini';
import { Recommendation, UserPreference } from '../types';
import { Button } from '../components/Button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../components/Card';
import { 
  MessageSquare, 
  Send, 
  User, 
  Bot, 
  Sparkles, 
  Info,
  ExternalLink,
  RefreshCcw,
  MapPin,
  Star,
  Settings
} from 'lucide-react';

const API_KEY = process.env.GEMINI_API_KEY || '';

interface Message {
  role: 'user' | 'bot';
  text: string;
  recommendations?: Recommendation[];
}

export const Chatbot = () => {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'bot', text: "Hello! I'm your TravelFlow AI assistant. How can I help you plan your next adventure today?" }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [userPrefs, setUserPrefs] = useState<UserPreference | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const fetchUserPrefs = async () => {
      if (!auth.currentUser) return;
      try {
        const q = query(
          collection(db, 'userPreferences'),
          where('uid', '==', auth.currentUser.uid),
          orderBy('updatedAt', 'desc'),
          limit(1)
        );
        const snapshot = await getDocs(q);
        let prefs: UserPreference;
        if (!snapshot.empty) {
          prefs = snapshot.docs[0].data() as UserPreference;
          setUserPrefs(prefs);
        } else {
          // Default preferences if none found
          prefs = {
            uid: auth.currentUser.uid,
            interests: ['beaches', 'culture'],
            budget: 'mid-range',
            travelStyle: 'relaxation',
            pastDestinations: [],
            updatedAt: new Date().toISOString()
          };
          setUserPrefs(prefs);
        }

        // Personalize greeting
        const name = auth.currentUser.displayName?.split(' ')[0] || 'Traveler';
        const interest = prefs.interests[0] || 'new destinations';
        setMessages([
          { role: 'bot', text: `Hello ${name}! Planning a trip to explore ${interest} sounds exciting. How can I help you today?` }
        ]);
      } catch (error) {
        console.error('Error fetching user preferences:', error);
      }
    };
    fetchUserPrefs();
  }, []);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || !API_KEY) return;

    const userMessage = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMessage }]);
    setLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: API_KEY });
      
      // Check if user is asking for recommendations
      const isAskingForRecs = userMessage.toLowerCase().includes('recommend') || 
                              userMessage.toLowerCase().includes('suggest') ||
                              userMessage.toLowerCase().includes('where should i go');

      let botResponse = '';
      let recommendations: Recommendation[] = [];

      if (isAskingForRecs && userPrefs) {
        recommendations = await getTravelRecommendations(userPrefs);
        botResponse = "Based on your preferences, I've found some amazing destinations for you! Take a look at these recommendations:";
      } else {
        const chat = ai.chats.create({
          model: "gemini-3-flash-preview",
          config: {
            systemInstruction: `You are a friendly travel assistant. User preferences: ${JSON.stringify(userPrefs)}. Use this context to personalize your answers.`,
          },
        });
        const response = await chat.sendMessage({ message: userMessage });
        botResponse = response.text;
      }
      
      setMessages(prev => [...prev, { role: 'bot', text: botResponse, recommendations }]);

      // Lead capture logic
      if (userMessage.includes('@') || userMessage.match(/\d{10}/)) {
        if (auth.currentUser) {
          await addDoc(collection(db, 'leads'), {
            name: 'Chatbot Lead',
            email: userMessage.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/)?.[0] || 'Unknown',
            source: 'AI Chatbot',
            createdAt: new Date().toISOString(),
            status: 'new',
            notes: `Captured from chat: ${userMessage}`,
            uid: auth.currentUser.uid,
          });
        }
      }
    } catch (error) {
      console.error(error);
      setMessages(prev => [...prev, { role: 'bot', text: "I'm sorry, I'm having trouble connecting right now. Please try again later." }]);
    } finally {
      setLoading(false);
    }
  };

  const getGreeting = () => {
    const name = auth.currentUser?.displayName?.split(' ')[0] || 'Traveler';
    const interest = userPrefs?.interests[0] || 'new destinations';
    return `Hello ${name}! Planning a trip to explore ${interest} sounds exciting. How can I help you today?`;
  };

  const handleReset = () => {
    setMessages([{ role: 'bot', text: getGreeting() }]);
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">AI Chatbot Assistant</h1>
          <p className="text-slate-500">Personalized travel recommendations and lead capture.</p>
        </div>
        <Button variant="outline" className="gap-2" onClick={handleReset}>
          <RefreshCcw className="h-4 w-4" />
          Reset Chat
        </Button>
      </div>

      <div className="grid gap-8 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-1">
          <Card className="border-slate-100">
            <CardHeader>
              <CardTitle>Recommendation Engine</CardTitle>
              <CardDescription>How we personalize your experience.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6 pt-4">
              {userPrefs ? (
                <div className="space-y-4">
                  <div className="rounded-xl bg-emerald-50 p-4 text-sm">
                    <h4 className="mb-2 font-semibold text-emerald-900">Your Profile</h4>
                    <div className="space-y-1 text-emerald-800">
                      <p><span className="font-medium">Style:</span> {userPrefs.travelStyle}</p>
                      <p><span className="font-medium">Budget:</span> {userPrefs.budget}</p>
                      <p><span className="font-medium">Interests:</span> {userPrefs.interests.join(', ')}</p>
                    </div>
                  </div>
                  <p className="text-xs text-slate-500">
                    Ask the chatbot "Where should I go?" to see your personalized recommendations.
                  </p>
                </div>
              ) : (
                <div className="animate-pulse space-y-3">
                  <div className="h-20 rounded-xl bg-slate-100" />
                  <div className="h-4 w-3/4 rounded bg-slate-100" />
                </div>
              )}
              
              <Button variant="outline" className="w-full gap-2">
                <Settings className="h-4 w-4" />
                Update Preferences
              </Button>
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-2">
          <Card className="flex h-[600px] flex-col border-slate-100 p-0 overflow-hidden">
            <div className="flex items-center gap-3 border-b border-slate-100 bg-slate-50/50 px-6 py-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-emerald-600 text-white">
                <Bot className="h-6 w-6" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900">TravelFlow AI Assistant</h3>
                <div className="flex items-center gap-1.5">
                  <span className="h-2 w-2 animate-pulse rounded-full bg-emerald-500" />
                  <span className="text-[10px] font-medium text-slate-500 uppercase tracking-wider">Online</span>
                </div>
              </div>
            </div>

            <div 
              ref={scrollRef}
              className="flex-1 space-y-4 overflow-y-auto p-6"
            >
              {messages.map((msg, i) => (
                <div key={i} className="space-y-4">
                  <div className={cn('flex items-start gap-3', msg.role === 'user' ? 'flex-row-reverse' : '')}>
                    <div className={cn(
                      'flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-white',
                      msg.role === 'user' ? 'bg-slate-800' : 'bg-emerald-600'
                    )}>
                      {msg.role === 'user' ? <User className="h-4 w-4" /> : <Bot className="h-4 w-4" />}
                    </div>
                    <div className={cn(
                      'max-w-[80%] rounded-2xl px-4 py-2.5 text-sm shadow-sm',
                      msg.role === 'user' 
                        ? 'bg-slate-800 text-white rounded-tr-none' 
                        : 'bg-white border border-slate-100 text-slate-800 rounded-tl-none'
                    )}>
                      {msg.text}
                    </div>
                  </div>
                  
                  {msg.recommendations && msg.recommendations.length > 0 && (
                    <div className="ml-11 grid gap-4 sm:grid-cols-2">
                      {msg.recommendations.map((rec, idx) => (
                        <div key={idx} className="rounded-xl border border-emerald-100 bg-emerald-50/30 p-4 shadow-sm">
                          <div className="mb-2 flex items-center justify-between">
                            <div className="flex items-center gap-2 font-bold text-emerald-900">
                              <MapPin className="h-4 w-4 text-emerald-600" />
                              {rec.destination}
                            </div>
                            <div className="flex items-center gap-1 text-xs font-bold text-emerald-600">
                              <Star className="h-3 w-3 fill-current" />
                              {rec.matchScore}%
                            </div>
                          </div>
                          <p className="mb-3 text-xs text-emerald-800/80">{rec.reason}</p>
                          <div className="flex flex-wrap gap-1">
                            {rec.activities.slice(0, 3).map((act, aIdx) => (
                              <span key={aIdx} className="rounded-full bg-white px-2 py-0.5 text-[10px] font-medium text-emerald-700 border border-emerald-100">
                                {act}
                              </span>
                            ))}
                          </div>
                          <div className="mt-3 flex items-center justify-between border-t border-emerald-100 pt-2">
                            <span className="text-[10px] font-bold text-emerald-600 uppercase tracking-wider">{rec.estimatedCost}</span>
                            <Button size="sm" className="h-7 px-3 text-[10px]">View Package</Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ))}
              {loading && (
                <div className="flex items-start gap-3">
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-emerald-600 text-white">
                    <Bot className="h-4 w-4" />
                  </div>
                  <div className="flex items-center gap-1 rounded-2xl bg-white border border-slate-100 px-4 py-2.5 text-slate-400 shadow-sm">
                    <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-slate-300" />
                    <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-slate-300 [animation-delay:0.2s]" />
                    <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-slate-300 [animation-delay:0.4s]" />
                  </div>
                </div>
              )}
            </div>

            <div className="border-t border-slate-100 bg-white p-4">
              <form 
                onSubmit={(e) => { e.preventDefault(); handleSend(); }}
                className="flex items-center gap-2"
              >
                <input
                  type="text"
                  placeholder="Ask for a recommendation..."
                  className="flex-1 rounded-xl border border-slate-200 bg-slate-50 px-4 py-2.5 text-sm focus:border-emerald-500 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  disabled={loading}
                />
                <Button 
                  type="submit" 
                  size="icon" 
                  disabled={!input.trim() || loading}
                  className="rounded-xl"
                >
                  <Send className="h-5 w-5" />
                </Button>
              </form>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};

function cn(...inputs: any[]) {
  return inputs.filter(Boolean).join(' ');
}
