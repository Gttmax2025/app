import React, { useEffect, useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { onAuthStateChanged, User } from 'firebase/auth';
import { auth, db, OperationType, handleFirestoreError } from './firebase';
import { collection, query, where, getDocs, addDoc } from 'firebase/firestore';
import { Layout } from './components/Layout';
import { ErrorBoundary } from './components/ErrorBoundary';
import { Login } from './pages/Login';
import { Dashboard } from './pages/Dashboard';
import { ContentGenerator } from './pages/ContentGenerator';
import { LeadCRM } from './pages/LeadCRM';
import { SEOTools } from './pages/SEOTools';
import { Chatbot } from './pages/Chatbot';
import { Analytics } from './pages/Analytics';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setUser(user);
      if (user) {
        await seedInitialData(user.uid);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const seedInitialData = async (uid: string) => {
    try {
      const q = query(collection(db, 'analytics'), where('uid', '==', uid));
      const snapshot = await getDocs(q);
      
      if (snapshot.empty) {
        const today = new Date();
        const promises = [];
        for (let i = 6; i >= 0; i--) {
          const date = new Date(today);
          date.setDate(today.getDate() - i);
          promises.push(addDoc(collection(db, 'analytics'), {
            date: date.toISOString().split('T')[0],
            traffic: Math.floor(Math.random() * 500) + 100,
            leadsGenerated: Math.floor(Math.random() * 20) + 5,
            conversions: Math.floor(Math.random() * 5) + 1,
            uid: uid
          }));
        }
        await Promise.all(promises);
      }
    } catch (error) {
      console.error('Error seeding data:', error);
    }
  };

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-50">
        <div className="flex flex-col items-center gap-4">
          <div className="h-12 w-12 animate-spin rounded-full border-4 border-emerald-600 border-t-transparent" />
          <p className="text-sm font-medium text-slate-500">Initializing TravelFlow AI...</p>
        </div>
      </div>
    );
  }

  return (
    <ErrorBoundary>
      <BrowserRouter>
        {!user ? (
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="*" element={<Navigate to="/login" replace />} />
          </Routes>
        ) : (
          <Layout>
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/content" element={<ContentGenerator />} />
              <Route path="/leads" element={<LeadCRM />} />
              <Route path="/seo" element={<SEOTools />} />
              <Route path="/chatbot" element={<Chatbot />} />
              <Route path="/analytics" element={<Analytics />} />
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </Layout>
        )}
      </BrowserRouter>
    </ErrorBoundary>
  );
}
