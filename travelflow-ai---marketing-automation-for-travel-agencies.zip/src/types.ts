export type ContentType = 'blog' | 'social' | 'email' | 'itinerary';

export interface Lead {
  id: string;
  email: string;
  name: string;
  source: string;
  createdAt: string;
  status: 'new' | 'contacted' | 'converted' | 'lost';
  notes?: string;
  uid: string;
}

export interface MarketingContent {
  id: string;
  type: ContentType;
  title: string;
  body: string;
  seoKeywords?: string[];
  createdAt: string;
  destination?: string;
  uid: string;
}

export interface AnalyticsData {
  id: string;
  date: string;
  traffic: number;
  leadsGenerated: number;
  conversions: number;
  uid: string;
}

export interface UserPreference {
  uid: string;
  interests: string[];
  budget: 'budget' | 'mid-range' | 'luxury';
  travelStyle: 'adventure' | 'relaxation' | 'culture' | 'family';
  pastDestinations: string[];
  updatedAt: string;
}

export interface Recommendation {
  destination: string;
  reason: string;
  activities: string[];
  estimatedCost: string;
  matchScore: number;
}

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  agencyName?: string;
}
